package com.robot;

import org.omg.CORBA.portable.InputStream;

public class RunBatAndInformU {

	public static void main(String[] args) {

	
	String s=	"[INFO] enrichment-cds .................................... FAILURE [11.";
	int i=s.indexOf("...");
	
	String trimStr=s.substring(7,i);
//			/ds ..
	System.out.println(trimStr.trim());
	System.out.println();    
 
	}
}
