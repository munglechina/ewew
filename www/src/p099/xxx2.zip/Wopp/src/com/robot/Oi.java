package com.robot;

import java.awt.GraphicsDevice;
import java.awt.GraphicsEnvironment;

public class Oi {
	public static void main(String[] args) {
		RectD rd = new RectD();
		GraphicsDevice gd = GraphicsEnvironment.getLocalGraphicsEnvironment()
				.getDefaultScreenDevice();
		gd.setFullScreenWindow(rd);
	}

}
