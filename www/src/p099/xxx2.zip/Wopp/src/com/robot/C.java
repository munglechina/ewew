package com.robot;

import java.io.File;
import java.net.MalformedURLException;

import org.junit.Test;

public class C {

	static String s = "";

	@Test
	public void a() throws MalformedURLException {

		// File file = new File("asd");
		//
		// String s=file.toURL().toString();
		// System.out.println(s);w
	
			
		T1 t1 = new T1();
		T2 t2 = new T2();
		t1.start();
		t2.start();
		for( ;;){
		}
	}

	class T1 extends Thread {

		@Override
		public void run() {
			// TODO Auto-generated method stub
			while (true) {
				synchronized (this) {
				s = s + "111";
				System.out.println(s);
				s = "";
				try {
					Thread.sleep(1111);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				s = s + "11111111";
				System.out.println(s);
				s = "";
				}
			}
		}

	}

	class T2 extends Thread {

		@Override
		public void run() {
			// TODO Auto-generated method stub
			while (true) {
				synchronized (this) {
					
			

				s = s + "222";
				System.out.println(s);
				s = "";
				try {
					Thread.sleep(1111);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				s = s + "2222222";
				System.out.println(s);
				s = "";
				}
			}
		}

	}

}
