package com.robot;

import java.math.BigDecimal;

import org.junit.Test;

public class We2222  {
	
	@Test
	public void a(){
		
		
		BigDecimal bd=BigDecimal.ZERO;
		System.out.println(new BigDecimal("0").equals(bd));
	}

}
