package net.quhw.jcapture.editor;

import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Graphics;

import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JList;
import javax.swing.ListCellRenderer;

public class LineComboBox extends JComboBox {
	private static final long serialVersionUID = -8783522250365760839L;

	public LineComboBox() {
		setEditable(false);

		addItem(1);
		addItem(2);
		addItem(3);
		addItem(4);
		addItem(5);
		addItem(6);
		
		setSelectedIndex(1);

		setRenderer(new LineRenderer());
	}

	public int getSelectedWidth() {
		return (Integer) getSelectedItem();
	}

	private class LineRenderer implements ListCellRenderer {
		@Override
		public Component getListCellRendererComponent(JList list, Object value,
				int index, boolean isSelected, boolean cellHasFocus) {
			return new LineComp((Integer) value, isSelected);
		}
	}

	private static class LineComp extends JComponent {
		private static final long serialVersionUID = -8534083919607117529L;

		private int width;
		private boolean selected = false;

		public LineComp(int width, boolean selected) {
			this.width = width;
			this.selected = selected;
		}

		@Override
		public void paint(Graphics g) {
			if (selected) {
				g.setColor(Color.blue);
			} else {
				g.setColor(Color.white);
			}
			g.fillRect(0, 0, getWidth(), getHeight());
			g.setColor(Color.black);
			int m = (getHeight() - width) / 2;
			g.fillRect(2, m, getWidth() - 5, width);
		}

		@Override
		public Dimension getPreferredSize() {
			return new Dimension(32, 16);
		}

	}
}
