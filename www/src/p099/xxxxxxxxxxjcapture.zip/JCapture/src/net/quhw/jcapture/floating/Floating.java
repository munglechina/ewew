package net.quhw.jcapture.floating;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Point;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;

import javax.swing.BorderFactory;
import javax.swing.JComponent;
import javax.swing.JPanel;
import javax.swing.border.BevelBorder;

public class Floating extends JComponent {
	private static final long serialVersionUID = 2301278359357649810L;

	private JPanel handlePanel, contentPanel;

	public Floating(JComponent comp) {
		initComponent();
		contentPanel.add(comp);
	}

	private void initComponent() {
		setLayout(new BorderLayout());
		setBorder(BorderFactory.createBevelBorder(BevelBorder.RAISED));

		handlePanel = new HandlePanel();

		contentPanel = new JPanel(new BorderLayout());

		add(handlePanel, BorderLayout.WEST);
		add(contentPanel);
	}

	class HandlePanel extends JPanel {
		private static final long serialVersionUID = -3032506798975867988L;
		private Point offset;

		public HandlePanel() {
			setPreferredSize(new Dimension(10, 10));

			addMouseListener(new MouseAdapter() {
				@Override
				public void mousePressed(MouseEvent e) {
					offset = e.getPoint();
				}
			});
//			javax.swing.Class SwingUtilities

			addMouseMotionListener(new MouseMotionAdapter() {
				@Override
				public void mouseDragged(MouseEvent e) {
					Point p = e.getLocationOnScreen();
					p.translate(-offset.x, -offset.y);
					Point p2 = Floating.this.getParent().getLocationOnScreen();
					p.translate(-p2.x, -p2.y);
					Floating.this.setLocation(p);
				}
			});
		}

		@Override
		protected void paintComponent(Graphics g) {
			g.setColor(getBackground());
			g.fillRect(0, 0, getWidth(), getHeight());

			g.setColor(Color.LIGHT_GRAY);

			int h = getHeight();

			g.drawLine(3, 2, 3, h - 3);
			g.drawLine(6, 2, 6, h - 3);
		}

	}
}
