package net.quhw.jcapture;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

import javax.swing.JOptionPane;

import org.apache.log4j.Logger;

public class AutoUpdater {
	static private Logger logger = Logger.getLogger(AutoUpdater.class);
	static private AutoUpdater instance;

	private AutoUpdater() {

	}

	synchronized static public AutoUpdater getInstance() {
		if (instance == null)
			instance = new AutoUpdater();
		return instance;
	}

	public void start() {
		TimerTask task = new TimerTask() {
			@Override
			public void run() {
				checkForUpdate();
			}
		};

		Timer timer = new Timer(true);
		timer.schedule(task, 1000 * 60 * 5, 1000 * 60 * 5);
		// timer.schedule(task, 1000 * 5, 1000 * 5);
	}

	private void checkForUpdate() {
		logger.debug("Checking for update");

		File jarFile = getAppJarFile();
		if (jarFile == null) {
			logger.debug("Application is not started from Jar file.");
			return;
		}

		File path = jarFile.getParentFile();
		String jarName = jarFile.getName();
		String name = getName(jarName);
		String currentVersion = getVersion(jarName);
		String pat = name + "-\\p{Digit}{12}\\.jar";

		File[] files = path.listFiles();
		List<String> names = new ArrayList<String>();
		for (File file : files) {
			if (file.getName().matches(pat)) {
				names.add(file.getName());
			}
		}
		if (names.size() <= 0)
			return;

		String[] na = new String[names.size()];
		names.toArray(na);
		Arrays.sort(na);
		String latestFileName = na[na.length - 1];
		String latestVersion = getVersion(latestFileName);
		if (latestVersion.compareTo(currentVersion) > 0) {
			File latestJarFile = new File(path, latestFileName);
			update(latestJarFile);
		}
	}

	private void update(File jarFile) {
		logger.debug("New version detected: " + jarFile.getPath());
		Main.getInstance().setVisible(true);
		Main.getInstance().toFront();
		int ret = JOptionPane
				.showConfirmDialog(
						Main.getInstance(),
						"A new version "
								+ jarFile.getPath()
								+ " has been detected.\nDo you want to restart the application now?",
						"Restart", JOptionPane.YES_NO_OPTION);
		if (ret == JOptionPane.YES_OPTION) {
			restartApplication(jarFile);
		}
	}

	public String getName(String file) {
		return file.substring(0, file.length() - "-yyyyMMddHHmm.jar".length());
	}

	public String getVersion(String file) {
		return file.substring(file.length() - "yyyyMMddHHmm.jar".length(),
				file.length() - ".jar".length());
	}

	private boolean restartApplication(File jarFile) {
		logger.info("Restarting the application");

		File startBatch = new File(jarFile.getParent(), "start.bat");
		if (startBatch.exists()) {
			try {
				Runtime.getRuntime().exec(startBatch.getAbsolutePath());
				Main.getInstance().exit();
				return true;
			} catch (Exception e) {
				e.printStackTrace();
				JOptionPane.showMessageDialog(null, e.getMessage());
			}
		}

		return false;
	}

	public File getAppJarFile() {
		File jarFile = null;
		try {
			jarFile = new File(this.getClass().getProtectionDomain()
					.getCodeSource().getLocation().toURI());
		} catch (Exception e) {
		}
		if (jarFile.getName().endsWith("jar"))
			return jarFile;
		else
			return null;
	}
}
