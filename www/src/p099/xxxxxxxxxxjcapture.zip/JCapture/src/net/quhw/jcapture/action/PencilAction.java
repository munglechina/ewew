package net.quhw.jcapture.action;

import java.awt.BasicStroke;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.image.BufferedImage;

public class PencilAction extends AbstractAction {
	private Point lastPoint;

	@Override
	protected void onPressed(Point p) {
		lastPoint = p;
	}

	@Override
	protected void onReleased(Point p) {
	}

	@Override
	protected void onMoved(Point p) {
		BufferedImage image = editor.getEditImg();
		if (image == null)
			return;
		Rectangle rect = editor.getEditRect();
		if (rect == null)
			return;

		Graphics2D g = (Graphics2D) image.getGraphics();
		try {
			g.setColor(editor.getSelectedColor());

			int lw = editor.getSelectedLineWidth();
			g.setStroke(new BasicStroke(lw));

			g.drawLine(lastPoint.x - rect.x, lastPoint.y - rect.y,
					p.x - rect.x, p.y - rect.y);
			int x = Math.min(lastPoint.x, p.x);
			int y = Math.min(lastPoint.y, p.y);
			int w = Math.abs(lastPoint.x - p.x);
			int h = Math.abs(lastPoint.y - p.y);
			editor.repaint(getScaledRect(new Rectangle(x, y, w, h), lw));
		} finally {
			g.dispose();
		}

		lastPoint = p;
	}
}
