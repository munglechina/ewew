package net.quhw.jcapture;

import java.awt.Graphics;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.URL;

import javax.swing.ImageIcon;

public class Utils {
	static public String getIP() {
		String myIp = "UNKNOWN";

		InetAddress addrs[];
		try {
			String hostName = InetAddress.getLocalHost().getHostName();
			addrs = InetAddress.getAllByName(hostName);
		} catch (Exception e) {
			e.printStackTrace();
			return myIp;
		}

		for (InetAddress addr : addrs) {
			if (!addr.isLoopbackAddress() && addr.isSiteLocalAddress()) {
				myIp = addr.getHostAddress();
			}
		}
		return myIp;
	}

	static public ImageIcon getImageIcon(String name) {
		URL url = Utils.class.getResource("/images/" + name);
		if (url != null) {
			return new ImageIcon(url);
		} else {
			return null;
		}
	}

	static public BufferedImage convertToBufferredImage(Image img) {
		BufferedImage image = new BufferedImage(img.getWidth(null),
				img.getHeight(null), BufferedImage.TYPE_INT_ARGB);
		Graphics g = image.getGraphics();
		g.drawImage(img, 0, 0, null);
		g.dispose();
		return image;
	}

	static public void fromJarToFs(String jarPath, String filePath)
			throws IOException {
		File file = new File(filePath);
		if (file.exists()) {
			boolean success = file.delete();
			if (!(success)) {
				throw new IOException("couldn't delete " + filePath);
			}
		}
		InputStream is = null;
		OutputStream os = null;
		try {
			is = Utils.class.getResourceAsStream(jarPath);
			os = new FileOutputStream(filePath);
			byte[] buffer = new byte[8192];
			int bytesRead;

			while ((bytesRead = is.read(buffer)) != -1) {
				os.write(buffer, 0, bytesRead);
			}
		} finally {
			if (is != null) {
				is.close();
			}
			if (os != null)
				os.close();
		}
	}
}
