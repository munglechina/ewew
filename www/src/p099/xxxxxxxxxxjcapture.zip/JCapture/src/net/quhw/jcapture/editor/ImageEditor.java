package net.quhw.jcapture.editor;

import java.awt.AlphaComposite;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.Stroke;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JToggleButton;
import javax.swing.JToolBar;
import javax.swing.undo.UndoManager;

import net.quhw.jcapture.Utils;
import net.quhw.jcapture.action.EllipseAction;
import net.quhw.jcapture.action.ImageEditorAction;
import net.quhw.jcapture.action.LineAction;
import net.quhw.jcapture.action.PencilAction;
import net.quhw.jcapture.action.RectAction;
import net.quhw.jcapture.action.SelectAction;
import net.quhw.jcapture.floating.Floating;
import net.quhw.jcapture.floating.FloatingLayout;

import org.apache.log4j.Logger;

public class ImageEditor extends JComponent implements ActionListener {
	private static final long serialVersionUID = -432619176243284142L;
	private static Logger logger = Logger.getLogger(ImageEditor.class);

	private BufferedImage image, flipImg, editImg;
	private Rectangle editRect;
	private ImageEditorAction action;
	private boolean selecting;

	private ImageCutter cutter;
	private ImageCutterHandler handler;

	private Floating floating;

	private JButton copyBtn, cancelBtn, undoBtn, redoBtn;

	private JToggleButton pencilBtn, rectBtn, ellipseBtn, lineBtn;

	private ColorComboBox colorBox;

	private LineComboBox lineBox;
	
	private FillComboBox fillBox;

	private UndoManager undoManager = new UndoManager();

	public ImageEditor(ImageCutter cutter) {
		this.cutter = cutter;

		setLayout(new FloatingLayout());
		createFloating();
		add(floating, "Float");
		add(new ImageComp());

		undoManager.setLimit(5);

		setFocusable(true);

		initListeners();
	}

	public BufferedImage getEditImg() {
		return editImg;
	}

	public void setEditImg(BufferedImage img) {
		editImg = img;
		repaint();
	}

	public void saveUndo(BufferedImage oldImg) {
		ImageEdit edit = new ImageEdit(this, oldImg, editImg);
		undoManager.addEdit(edit);
		resetUndoButtons();
	}

	public Rectangle getEditRect() {
		return editRect;
	}

	public void setEditRect(Rectangle editRect) {
		this.editRect = editRect;
	}

	public Color getSelectedColor() {
		return colorBox.getSelectedColor();
	}

	public int getSelectedLineWidth() {
		return lineBox.getSelectedWidth();
	}
	
	public boolean getFillMode(){
		return fillBox.getFillMode();
	}

	private void createFloating() {
		JToolBar toolbar = new JToolBar();
		toolbar.setFloatable(false);

		copyBtn = makeButton("camera-photo.png", "Copy", "Copy", "Copy");
		cancelBtn = makeButton("process-stop.png", "Cancel", "Cancel", "Cancel");
		pencilBtn = makeToggleButton("pencil.png", "Pencil", "Pencil", "Pencil");
		lineBtn = makeToggleButton("line.gif", "Line", "Line", "Line");
		rectBtn = makeToggleButton("rect.PNG", "Rectangle", "Rectangle",
				"Rectangle");
		ellipseBtn = makeToggleButton("ellipse_bw.gif", "Ellipse", "Ellipse",
				"Ellipse");

		colorBox = new ColorComboBox();
		colorBox.setFocusable(false);
		lineBox = new LineComboBox();
		lineBox.setFocusable(false);
		fillBox = new FillComboBox();
		fillBox.setFocusable(false);

		undoBtn = makeButton("edit-undo.png", "Undo", "Undo", "Undo");
		redoBtn = makeButton("edit-redo.png", "Redo", "Redo", "Redo");

		toolbar.add(copyBtn);
		toolbar.add(cancelBtn);
		toolbar.addSeparator();
		toolbar.add(pencilBtn);
		toolbar.add(lineBtn);
		toolbar.add(rectBtn);
		toolbar.add(ellipseBtn);
		toolbar.addSeparator();
		toolbar.add(colorBox);
		toolbar.add(lineBox);
		toolbar.add(fillBox);
		toolbar.addSeparator();
		toolbar.add(undoBtn);
		toolbar.add(redoBtn);

		floating = new Floating(toolbar);
	}

	private JToggleButton makeToggleButton(String imageName,
			String actionCommand, String toolTipText, String altText) {
		// Create and initialize the button.
		JToggleButton button = new JToggleButton();
		button.setActionCommand(actionCommand);
		button.addActionListener(this);
		button.setToolTipText(toolTipText);
		button.setFocusable(false);

		ImageIcon icon;
		if (imageName != null && (icon = Utils.getImageIcon(imageName)) != null) {
			button.setIcon(icon);
		} else { // no image found
			button.setText(altText);
		}

		return button;
	}

	private JButton makeButton(String imageName, String actionCommand,
			String toolTipText, String altText) {
		// Create and initialize the button.
		JButton button = new JButton();
		button.setActionCommand(actionCommand);
		button.addActionListener(this);
		button.setToolTipText(toolTipText);
		button.setFocusable(false);

		ImageIcon icon;
		if (imageName != null && (icon = Utils.getImageIcon(imageName)) != null) {
			button.setIcon(icon);
		} else { // no image found
			button.setText(altText);
		}

		return button;
	}

	public Floating getFloating() {
		return floating;
	}

	public void editImage(BufferedImage image, ImageCutterHandler handler) {
		this.image = image;
		this.handler = handler;
		if (this.flipImg == null || this.flipImg.getWidth() != image.getWidth()
				|| this.flipImg.getHeight() != image.getHeight()) {
			this.flipImg = new BufferedImage(image.getWidth(),
					image.getHeight(), BufferedImage.TYPE_INT_ARGB);
		}
		undoManager.discardAllEdits();
		resetUndoButtons();

		editRect = null;
		editImg = null;
		selecting = true;
		action = new SelectAction();
		action.edit(this);

		resetToggleButtons();

		requestFocusInWindow();

		repaint();
	}

	private void resetUndoButtons() {
		undoBtn.setEnabled(undoManager.canUndo());
		redoBtn.setEnabled(undoManager.canRedo());
	}

	private void initListeners() {
		addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent e) {
				if (e.getKeyChar() == KeyEvent.VK_ESCAPE) {
					finish(false);
				} else if (e.getKeyChar() == KeyEvent.VK_ENTER) {
					finish(true);
				}
			}
		});

		addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				if (e.getButton() == MouseEvent.BUTTON1
						&& e.getClickCount() == 2 && selecting) {
					Point p = e.getPoint();
					if (editRect.contains(p)) {
						finish(true);
					}
				}
			}
		});
	}

	private void finish(boolean save) {
		action.finish();
		cutter.finish();
		if (handler != null) {
			BufferedImage img = null;
			if (save && editRect != null && editRect.width > 0
					&& editRect.height > 0) {
				Rectangle rect = getBounds().intersection(editRect);

				img = new BufferedImage(rect.width, rect.height,
						BufferedImage.TYPE_INT_ARGB);
				Graphics2D g = img.createGraphics();
				try {
					g.drawImage(image, 0, 0, rect.width, rect.height, rect.x,
							rect.y, rect.x + rect.width, rect.y + rect.height,
							null);
					if (editImg != null) {
						g.setComposite(AlphaComposite.getInstance(
								AlphaComposite.SRC_OVER, 1.0f));
						rect.translate(-editRect.x, -editRect.y);
						g.drawImage(editImg, 0, 0, rect.width, rect.height,
								rect.x, rect.y, rect.x + rect.width, rect.y
										+ rect.height, null);
					}
				} finally {
					g.dispose();
				}
			}
			handler.onCut(img);
			handler = null;
		}
	}

	private class ImageComp extends JComponent {
		private static final long serialVersionUID = 3147538436592847499L;

		@Override
		public void paint(Graphics g) {
			if (image == null) {
				logger.debug("Image is null");
				return;
			}

			Rectangle r = g.getClipBounds();

			Graphics2D bg = flipImg.createGraphics();
			try {
				bg.setColor(Color.black);
				bg.fillRect(r.x, r.y, r.width, r.height);

				bg.setComposite(AlphaComposite.getInstance(
						AlphaComposite.SRC_OVER, 0.5f));
				bg.drawImage(image, r.x, r.y, r.x + r.width, r.y + r.height,
						r.x, r.y, r.x + r.width, r.y + r.height, null);

				if (editRect != null && editRect.width > 0
						&& editRect.height > 0) {
					bg.setComposite(AlphaComposite
							.getInstance(AlphaComposite.SRC));
					bg.drawImage(image, editRect.x, editRect.y, editRect.x
							+ editRect.width + 1, editRect.y + editRect.height
							+ 1, editRect.x, editRect.y, editRect.x
							+ editRect.width + 1, editRect.y + editRect.height
							+ 1, null);

					if (editImg != null) {
						bg.setComposite(AlphaComposite.getInstance(
								AlphaComposite.SRC_OVER, 1.0f));
						bg.drawImage(editImg, editRect.x, editRect.y, null);
					}

					Stroke dash = new BasicStroke(1f, BasicStroke.CAP_BUTT,
							BasicStroke.JOIN_BEVEL, 0, new float[] { 5, 1 }, 0);
					bg.setStroke(dash);
					bg.setColor(Color.red);
					bg.drawRect(editRect.x, editRect.y, editRect.width,
							editRect.height);
				}

				if (selecting && editRect != null && editRect.width > 20
						&& editRect.height > 20) {
					for (Point p : SelectAction.getDragPoints(editRect)) {
						bg.fillRect(p.x - 2, p.y - 2, 5, 5);
					}
				}

				// flip
				g.drawImage(flipImg, r.x, r.y, r.x + r.width, r.y + r.height,
						r.x, r.y, r.x + r.width, r.y + r.height, null);
			} finally {
				bg.dispose();
			}
		}
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		String cmd = e.getActionCommand();
		if ("Copy".equals(cmd)) {
			finish(true);
		} else if ("Cancel".equals(cmd)) {
			finish(false);
		} else if ("Pencil".equals(cmd)) {
			if (pencilBtn.isSelected()) {
				resetToggleButtons();
				switchAction(new PencilAction());
			}
			pencilBtn.setSelected(true);
		} else if ("Line".equals(cmd)) {
			if (lineBtn.isSelected()) {
				resetToggleButtons();
				switchAction(new LineAction());
			}
			lineBtn.setSelected(true);
		} else if ("Rectangle".equals(cmd)) {
			if (rectBtn.isSelected()) {
				resetToggleButtons();
				switchAction(new RectAction());
			}
			rectBtn.setSelected(true);
		} else if ("Ellipse".equals(cmd)) {
			if (ellipseBtn.isSelected()) {
				resetToggleButtons();
				switchAction(new EllipseAction());
			}
			ellipseBtn.setSelected(true);
		} else if ("Undo".equals(cmd)) {
			if (undoManager.canUndo())
				undoManager.undo();
			resetUndoButtons();
		} else if ("Redo".equals(cmd)) {
			if (undoManager.canRedo())
				undoManager.redo();
			resetUndoButtons();
		}
	}

	private void resetToggleButtons() {
		pencilBtn.setSelected(false);
		lineBtn.setSelected(false);
		rectBtn.setSelected(false);
		ellipseBtn.setSelected(false);
	}

	private void switchAction(ImageEditorAction newAction) {
		action.finish();
		action = newAction;
		action.edit(ImageEditor.this);
		selecting = false;
		repaint();
	}
}
