package net.quhw.jcapture.action;

import net.quhw.jcapture.editor.ImageEditor;

public interface ImageEditorAction {
	public void edit(ImageEditor editor);

	public void finish();
}
