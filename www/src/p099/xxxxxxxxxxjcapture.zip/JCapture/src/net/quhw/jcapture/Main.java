package net.quhw.jcapture;

import java.awt.GraphicsConfiguration;
import java.awt.MouseInfo;
import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.image.BufferedImage;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.UIManager;

import net.quhw.jcapture.editor.ImageCutterHandler;
import net.quhw.jcapture.editor.ImageSelection;
import net.quhw.jcapture.editor.ScreenShot;

import org.apache.log4j.BasicConfigurator;
import org.apache.log4j.Logger;

import com.melloware.jintellitype.HotkeyListener;
import com.melloware.jintellitype.JIntellitype;

public class Main extends JFrame {
	private static final long serialVersionUID = -8261315083023482958L;

	static private Main instance;
	private Logger logger = Logger.getLogger(Main.class);

	public static void main(String[] args) {
		BasicConfigurator.configure();

		if (Singleton.lock()) {
			try {
				UIManager.setLookAndFeel(UIManager
						.getSystemLookAndFeelClassName());
				AutoUpdater.getInstance().start();
				Main.getInstance();
			} catch (Exception e) {
				e.printStackTrace();
				System.exit(-1);
			}
		} else {
			JOptionPane.showMessageDialog(null,
					"Another instance is running, cannot start up!", "Info",
					JOptionPane.INFORMATION_MESSAGE);
			System.exit(-1);
		}
	}

	public static Main getInstance() {
		if (instance == null) {
			instance = new Main();
		}
		return instance;
	}

	public Main() {
		pack();
		setVisible(false);
		ClientTray.getInstance();

		try {
			JIntellitype.getInstance();
		} catch (Exception e) {
		}

		initListeners();
	}

	private void initListeners() {
		try {
			// JIntellitype.getInstance().registerHotKey(1,
			// JIntellitype.MOD_CONTROL + JIntellitype.MOD_ALT, (int) 'A');
			
			//PrintScreen
			JIntellitype.getInstance().registerHotKey(2, 0, 44);
			JIntellitype.getInstance().addHotKeyListener(new HotkeyListener() {
				@Override
				public void onHotKey(int e) {
					capture();
				}
			});
		} catch (Exception e) {
			logger.warn("Cannot register system shortcut(Ctrl+Alt+A)");
		}
	}

	private void capture() {
		GraphicsConfiguration gc = MouseInfo.getPointerInfo().getDevice()
				.getDefaultConfiguration();

		ScreenShot.captureCustomerScreenShot(gc, new ImageCutterHandler() {
			@Override
			public void onCut(BufferedImage img) {
				if (img != null) {
					Clipboard clipboard = Toolkit.getDefaultToolkit()
							.getSystemClipboard();
					clipboard.setContents(new ImageSelection(img), null);
				}
			}
		});
	}

	public void exit() {
		try {
			JIntellitype.getInstance().cleanUp();
		} catch (Exception e) {
		}
		System.exit(0);
	}
}
