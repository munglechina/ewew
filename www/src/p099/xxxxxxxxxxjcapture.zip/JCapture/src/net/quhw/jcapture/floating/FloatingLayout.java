package net.quhw.jcapture.floating;

import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Insets;
import java.awt.LayoutManager2;

public class FloatingLayout implements LayoutManager2 {
	private Component floating;

	@Override
	public void addLayoutComponent(String name, Component comp) {
		if ("Float".equalsIgnoreCase(name)) {
			floating = comp;
		}
	}

	private Component getContentComponent(Container parent) {
		Component[] comps = parent.getComponents();
		if (comps != null) {
			for (Component comp : comps) {
				if (comp != floating)
					return comp;
			}
		}
		return null;
	}

	@Override
	public void layoutContainer(Container parent) {
		synchronized (parent.getTreeLock()) {
			Component content = getContentComponent(parent);
			if (content != null) {
				Insets localInsets = parent.getInsets();
				int top = localInsets.top;
				int height = parent.getHeight() - localInsets.bottom
						- localInsets.top;
				int left = localInsets.left;
				int width = parent.getWidth() - localInsets.right
						- localInsets.left;
				content.setBounds(left, top, width, height);
				parent.setComponentZOrder(content, 1);
			}
			if (floating != null) {
				parent.setComponentZOrder(floating, 0);
				floating.setSize(floating.getPreferredSize());
			}
		}
	}

	@Override
	public Dimension minimumLayoutSize(Container parent) {
		Component content = getContentComponent(parent);
		if (content != null)
			return content.getMinimumSize();
		else
			return new Dimension(0, 0);
	}

	@Override
	public Dimension preferredLayoutSize(Container parent) {
		Component content = getContentComponent(parent);
		if (content != null)
			return content.getPreferredSize();
		else
			return new Dimension(0, 0);
	}

	@Override
	public void removeLayoutComponent(Component comp) {
	}

	@Override
	public void addLayoutComponent(Component comp, Object constraints) {
		if (constraints instanceof String) {
			addLayoutComponent((String) constraints, comp);
		}
	}

	@Override
	public float getLayoutAlignmentX(Container target) {
		return 0;
	}

	@Override
	public float getLayoutAlignmentY(Container target) {
		return 0;
	}

	@Override
	public void invalidateLayout(Container target) {
	}

	@Override
	public Dimension maximumLayoutSize(Container target) {
		Component content = getContentComponent(target);
		if (content != null)
			return content.getMaximumSize();
		else
			return new Dimension(0, 0);
	}

}
