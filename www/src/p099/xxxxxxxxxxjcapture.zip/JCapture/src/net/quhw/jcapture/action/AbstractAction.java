package net.quhw.jcapture.action;

import java.awt.AlphaComposite;
import java.awt.Cursor;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.image.BufferedImage;

import net.quhw.jcapture.editor.ImageEditor;

abstract public class AbstractAction implements ImageEditorAction,
		MouseListener, MouseMotionListener {
	protected ImageEditor editor;

	protected BufferedImage image2;

	protected Point startPoint;

	@Override
	public void edit(ImageEditor editor) {
		this.editor = editor;

		BufferedImage image = editor.getEditImg();
		image2 = new BufferedImage(image.getWidth(), image.getHeight(),
				BufferedImage.TYPE_4BYTE_ABGR);

		editor.addMouseListener(this);
		editor.addMouseMotionListener(this);
	}

	@Override
	public void finish() {
		editor.removeMouseListener(this);
		editor.removeMouseMotionListener(this);
		editor.setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
	}

	@Override
	public void mouseClicked(MouseEvent paramMouseEvent) {
	}

	@Override
	public void mousePressed(MouseEvent e) {
		if (e.getButton() == MouseEvent.BUTTON1) {
			startPoint = e.getPoint();
			copyImage(image2, editor.getEditImg());
			onPressed(startPoint);
			onMoved(startPoint);
		}
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		if (e.getButton() == MouseEvent.BUTTON1) {
			onMoved(e.getPoint());
			onReleased(e.getPoint());
			editor.saveUndo(image2);
		}
	}

	@Override
	public void mouseEntered(MouseEvent paramMouseEvent) {
	}

	@Override
	public void mouseExited(MouseEvent paramMouseEvent) {
	}

	@Override
	public void mouseDragged(MouseEvent e) {
		onMoved(e.getPoint());
	}

	@Override
	public void mouseMoved(MouseEvent e) {
	}

	abstract protected void onPressed(Point p);

	abstract protected void onReleased(Point p);

	abstract protected void onMoved(Point p);

	protected Rectangle getScaledRect(Rectangle r, int n) {
		return new Rectangle(r.x - n, r.y - n, r.width + n * 2, r.height + n
				* 2);
	}

	public void copyImage(BufferedImage dest, BufferedImage src) {
		Graphics2D g = dest.createGraphics();
		try {
			g.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC));
			g.drawImage(src, 0, 0, null);
		} finally {
			g.dispose();
		}
	}
}
