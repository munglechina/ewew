package net.quhw.jcapture.editor;

import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Graphics;

import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JList;
import javax.swing.ListCellRenderer;

public class ColorComboBox extends JComboBox {
	private static final long serialVersionUID = -8783522250365760839L;

	public ColorComboBox() {
		setEditable(false);

		addItem(Color.red);
		addItem(Color.black);
		addItem(Color.pink);
		addItem(Color.orange);
		addItem(Color.yellow);
		addItem(Color.green);
		addItem(Color.magenta);
		addItem(Color.cyan);
		addItem(Color.blue);
		addItem(Color.gray);
		addItem(Color.lightGray);
		addItem(Color.white);

		setRenderer(new ColorRenderer());
	}

	public Color getSelectedColor() {
		return (Color) getSelectedItem();
	}

	private class ColorRenderer implements ListCellRenderer {
		@Override
		public Component getListCellRendererComponent(JList list, Object value,
				int index, boolean isSelected, boolean cellHasFocus) {
			return new ColorComp((Color) value, isSelected);
		}
	}

	private static class ColorComp extends JComponent {
		private static final long serialVersionUID = -8534083919607117529L;

		private Color color;
		private boolean selected = false;

		public ColorComp(Color color, boolean selected) {
			this.color = color;
			this.selected = selected;
		}

		@Override
		public void paint(Graphics g) {
			if (selected) {
				g.setColor(color.equals(Color.blue) ? Color.red : Color.blue);
			} else {
				g.setColor(Color.white);
			}
			g.fillRect(0, 0, getWidth(), getHeight());
			g.setColor(color);
			g.fillRect(2, 2, getWidth() - 4, getHeight() - 4);
			g.setColor(Color.black);
			g.drawRect(2, 2, getWidth() - 5, getHeight() - 5);
		}

		@Override
		public Dimension getPreferredSize() {
			return new Dimension(32, 16);
		}

	}
}
