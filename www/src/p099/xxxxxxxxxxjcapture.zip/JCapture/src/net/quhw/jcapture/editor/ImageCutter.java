package net.quhw.jcapture.editor;

import java.awt.GraphicsConfiguration;
import java.awt.image.BufferedImage;

import javax.swing.JFrame;

public class ImageCutter extends JFrame {
	private static final long serialVersionUID = -2275754875262235178L;

	private static ImageCutter instance;

	private ImageEditor editor;

	static public ImageCutter getInstance() {
		if (instance == null) {
			instance = new ImageCutter();
		}
		return instance;
	}

	private ImageCutter() {
		setTitle("JCapture");
		setUndecorated(true);

		editor = new ImageEditor(this);
		add(editor);
	}

	public void edit(GraphicsConfiguration gc, BufferedImage img,
			ImageCutterHandler handler) {
		// gc.getDevice().setFullScreenWindow(this);
		setVisible(true);
		setAlwaysOnTop(true);
		setBounds(gc.getBounds());

		editor.editImage(img, handler);

	}

	public void finish() {
		dispose();
		System.gc();
	}

}
