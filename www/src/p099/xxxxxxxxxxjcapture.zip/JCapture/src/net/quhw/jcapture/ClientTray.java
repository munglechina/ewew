package net.quhw.jcapture;

import java.awt.AWTException;
import java.awt.Image;
import java.awt.MenuItem;
import java.awt.PopupMenu;
import java.awt.SystemTray;
import java.awt.TrayIcon;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import org.apache.log4j.Logger;

public class ClientTray {
	static private Logger logger = Logger.getLogger(ClientTray.class);

	static private String EXIT = "Exit";

	static private ClientTray instance;

	private TrayIcon tray;

	private Image icon;

 	private ClientTray() {
		if (!SystemTray.isSupported())
			return;

		ActionListener menuListener = new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				if (e.getActionCommand().equals(EXIT)) {
					logger.info("Quit the application");
					Main.getInstance().exit();
				}
			}
		};

		PopupMenu popup = new PopupMenu();
		MenuItem exitItem = new MenuItem(EXIT);
		exitItem.addActionListener(menuListener);
		popup.add(exitItem);

		icon = Utils.getImageIcon("capture.jpg").getImage();

		tray = new TrayIcon(icon, "JCapture <PrintScreen>", popup);
		tray.setImageAutoSize(true);
//		tray.
		try {
			SystemTray.getSystemTray().add(tray);
		} catch (AWTException e1) {
			logger.error(e1);
		}
		logger.info("System tray created");
	}

	synchronized static public ClientTray getInstance() {
		if (instance == null)
			instance = new ClientTray();
		return instance;
	}
}
