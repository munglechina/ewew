package net.quhw.jcapture.editor;

import java.awt.GraphicsConfiguration;
import java.awt.Rectangle;
import java.awt.Robot;
import java.awt.image.BufferedImage;

public class ScreenShot {
	static private boolean capturing = false;

	private ScreenShot() {
	}

	static private BufferedImage captureScreenShot(GraphicsConfiguration gc) {
		try {
			Robot robot = new Robot(gc.getDevice());
			Rectangle r = gc.getBounds();
			BufferedImage img = robot.createScreenCapture(new Rectangle(0, 0,
					r.width, r.height));
			robot = null;
			return img;
		} catch (Exception e) {
			e.printStackTrace();
		}

		return null;
	}

	static public void captureCustomerScreenShot(GraphicsConfiguration gc,
			final ImageCutterHandler handler) {
		if (!capturing) {
			capturing = true;
			BufferedImage image = captureScreenShot(gc);
			ImageCutter.getInstance().edit(gc, image, new ImageCutterHandler() {
				@Override
				public void onCut(BufferedImage image) {
					capturing = false;
					handler.onCut(image);
				}
			});
		}
	}

}
