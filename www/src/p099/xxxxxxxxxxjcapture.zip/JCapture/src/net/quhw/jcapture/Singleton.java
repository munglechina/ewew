package net.quhw.jcapture;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.channels.FileLock;

import org.apache.log4j.Logger;

public class Singleton extends Thread {
	static private Logger logger = Logger.getLogger(Singleton.class);
	private FileLock lock;

	static private Singleton inst;

	private Singleton() {
	}

	static public boolean lock() {
		logger.debug("Trying to get the file lock");

		if (inst == null)
			inst = new Singleton();

		if (inst.lock != null)
			return true;

		try {
			File file = getLockFile();
			File dir = file.getParentFile();
			if (!dir.exists())
				dir.mkdir();

			FileOutputStream fos = new FileOutputStream(file);
			inst.lock = fos.getChannel().tryLock();
			if (inst.lock != null) {
				inst.start();
				return true;
			} else {
				return false;
			}
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
	}

	static public void release() {
		logger.debug("Releasingt the file lock");

		if (inst != null && inst.lock != null) {
			try {
				inst.lock.release();
			} catch (IOException e) {
				e.printStackTrace();
			}
			inst.lock = null;
		}
	}

	static public File getLockFile() {
		String home = System.getProperty("user.home");
		File file = new File(home + "/.jcapture");
		return file;
	}

	// run forever to hold the lock
	public void run() {
		while (true) {
			try {
				Thread.sleep(100000);
			} catch (InterruptedException e) {
			}
		}
	}
}
