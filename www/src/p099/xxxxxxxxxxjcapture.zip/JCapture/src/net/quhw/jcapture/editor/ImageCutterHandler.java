package net.quhw.jcapture.editor;

import java.awt.image.BufferedImage;

public interface ImageCutterHandler {
	public void onCut(BufferedImage image);
}
