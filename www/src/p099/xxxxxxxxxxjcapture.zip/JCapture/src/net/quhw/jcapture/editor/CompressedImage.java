package net.quhw.jcapture.editor;

import java.awt.Dimension;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.Serializable;

import javax.imageio.ImageIO;

public class CompressedImage implements Serializable {
	private static final long serialVersionUID = 4451292125448924022L;
	private byte[] data;
	private Dimension size;

	public CompressedImage() {
	}

	public CompressedImage(BufferedImage img) {
		this();
		setData(img);
	}

	public CompressedImage(byte[] data) {
		this();
		this.data = data;
		BufferedImage img = getImage();
		size = new Dimension(img.getWidth(), img.getHeight());
	}

	private void setData(BufferedImage img) {
		data = null;
		size = null;
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		try {
			ImageIO.write(img, "PNG", baos);
			data = baos.toByteArray();
			size = new Dimension(img.getWidth(), img.getHeight());
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void setImage(BufferedImage img) {
		setData(img);
	}

	public Dimension getSize() {
		return size;
	}

	public BufferedImage getImage() {
		if (data == null)
			return null;
		ByteArrayInputStream bais = new ByteArrayInputStream(data);
		try {
			BufferedImage img = ImageIO.read(bais);
			return img;
		} catch (IOException e) {
			e.printStackTrace();
		}
		return null;
	}

	public byte[] getData() {
		return data;
	}

}
