package net.quhw.jcapture.editor;

import java.awt.image.BufferedImage;

import javax.swing.undo.AbstractUndoableEdit;
import javax.swing.undo.CannotRedoException;
import javax.swing.undo.CannotUndoException;

public class ImageEdit extends AbstractUndoableEdit {
	private static final long serialVersionUID = -2463409138583326356L;

	private CompressedImage oldImg, newImg;
	private ImageEditor editor;
	
	public ImageEdit(ImageEditor editor, BufferedImage oldImg, BufferedImage newImg){
		this.editor = editor;
		this.oldImg = new CompressedImage(oldImg);
		this.newImg = new CompressedImage(newImg);
	}

	@Override
	public void undo() throws CannotUndoException {
		super.undo();
		editor.setEditImg(oldImg.getImage());
	}

	@Override
	public void redo() throws CannotRedoException {
		super.redo();
		editor.setEditImg(newImg.getImage());
	}
	
	
}
