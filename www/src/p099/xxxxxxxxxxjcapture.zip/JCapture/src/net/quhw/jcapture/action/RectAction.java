package net.quhw.jcapture.action;

import java.awt.BasicStroke;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.image.BufferedImage;

public class RectAction extends AbstractAction {
	private Rectangle lastRect;

	protected void onMoved(Point p) {
		BufferedImage image = editor.getEditImg();
		copyImage(image, image2);
		Graphics2D g = (Graphics2D) image.getGraphics();
		Rectangle rect = editor.getEditRect();
		try {
			g.setColor(editor.getSelectedColor());

			int lw = editor.getSelectedLineWidth();
			g.setStroke(new BasicStroke(lw));

			int x = Math.min(startPoint.x, p.x);
			int y = Math.min(startPoint.y, p.y);
			int w = Math.abs(startPoint.x - p.x);
			int h = Math.abs(startPoint.y - p.y);

			if(editor.getFillMode())
				g.fillRect(x - rect.x, y - rect.y, w, h);
			else 
				g.drawRect(x - rect.x, y - rect.y, w, h);

			Rectangle rect2 = getScaledRect(new Rectangle(x, y, w, h), lw);

			editor.repaint(lastRect.union(rect2));

			lastRect = rect2;
		} finally {
			g.dispose();
		}
	}

	@Override
	protected void onPressed(Point p) {
		lastRect = new Rectangle();
	}

	@Override
	protected void onReleased(Point p) {
	}

}
