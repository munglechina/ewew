package net.quhw.jcapture.action;

import java.awt.Cursor;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.image.BufferedImage;

import net.quhw.jcapture.editor.ImageEditor;
import net.quhw.jcapture.floating.Floating;

public class SelectAction implements ImageEditorAction, MouseListener,
		MouseMotionListener {
	private ImageEditor editor;

	private Rectangle rect = new Rectangle(), startRect;
	private Point start = new Point(), end = new Point();
	private boolean dragging = false;

	final static private int N = 0;
	final static private int NE = 1;
	final static private int E = 2;
	final static private int SE = 3;
	final static private int S = 4;
	final static private int SW = 5;
	final static private int W = 6;
	final static private int NW = 7;
	final static private int IN = 9;
	final static private int OUT = -1;

	private int dir = -1;

	@Override
	public void edit(ImageEditor editor) {
		this.editor = editor;

		editor.addMouseListener(this);
		editor.addMouseMotionListener(this);

		showFloating();
	}

	@Override
	public void finish() {
		editor.removeMouseListener(this);
		editor.removeMouseMotionListener(this);
		editor.setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
		if (rect.width > 0 && rect.height > 0) {
			BufferedImage image = new BufferedImage(rect.width, rect.height,
					BufferedImage.TYPE_4BYTE_ABGR);
			editor.setEditImg(image);
		}
	}

	@Override
	public void mouseClicked(MouseEvent paramMouseEvent) {
	}

	@Override
	public void mousePressed(MouseEvent e) {
		if (e.getButton() == MouseEvent.BUTTON1) {

			dragging = true;
			showFloating();

			dir = getDir(rect, e.getPoint());
			switch (dir) {
			case IN:
				startRect = rect;
				start = new Point(e.getPoint());
				end = new Point(e.getPoint());
				break;
			case OUT:
				start = new Point(e.getPoint());
				end = new Point(e.getPoint());
				dir = SE;
				break;
			default:
				start = new Point(rect.x, rect.y);
				end = new Point(rect.x + rect.width, rect.y + rect.height);
				break;
			}
			refreshRect();
		}
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		if (e.getButton() == MouseEvent.BUTTON1) {
			onDrag(e.getPoint());
			dragging = false;
			showFloating();
		}
	}

	private void showFloating() {
		Floating floating = editor.getFloating();
		if (rect.width > 0 && rect.height > 0 && !dragging) {

			Rectangle fr = floating.getBounds();

			int h = editor.getHeight();

			int x, y;
			if (rect.y > fr.height + 10) {
				x = rect.x;
				y = rect.y - fr.height - 5;
			} else if (h - fr.height - 10 > rect.y + rect.height) {
				x = rect.x;
				y = rect.y + rect.height + 5;
			} else {
				x = rect.x + 20;
				y = rect.y + 20;
			}
			if (x + fr.width > editor.getWidth())
				x = editor.getWidth() - fr.width;
			if (x < 0) {
				x = 0;
			}
			if (y < 0) {
				y = 0;
			}

			floating.setLocation(x, y);

			floating.setVisible(true);
		} else {
			floating.setVisible(false);
		}
	}

	@Override
	public void mouseEntered(MouseEvent paramMouseEvent) {
	}

	@Override
	public void mouseExited(MouseEvent paramMouseEvent) {
	}

	private void onDrag(Point p) {
		int x = p.x;
		int y = p.y;
		switch (dir) {
		case N:
			start.y = y;
			break;
		case NE:
			start.y = y;
			end.x = x;
			break;
		case E:
			end.x = x;
			break;
		case SE:
			end.x = x;
			end.y = y;
			break;
		case S:
			end.y = y;
			break;
		case SW:
			start.x = x;
			end.y = y;
			break;
		case W:
			start.x = x;
			break;
		case NW:
			start.x = x;
			start.y = y;
			break;
		case IN:
			end = p;
			break;
		default:
			break;
		}
		refreshRect();
	}

	private void refreshRect() {
		Rectangle r = rect;

		if (dir == IN) {
			int dx = end.x - start.x;
			int dy = end.y - start.y;
			rect = new Rectangle(startRect.x + dx, startRect.y + dy,
					startRect.width, startRect.height);
		} else {
			int x = Math.min(start.x, end.x);
			int y = Math.min(start.y, end.y);
			int width = Math.abs(start.x - end.x);
			int height = Math.abs(start.y - end.y);
			rect = new Rectangle(x, y, width, height);
		}

		Rectangle r2 = getScaledRect(r.union(rect), 3);

		editor.setEditRect(rect);

		editor.repaint(r2.x, r2.y, r2.width, r2.height);
	}

	private Rectangle getScaledRect(Rectangle r, int n) {
		return new Rectangle(r.x - n, r.y - n, r.width + n * 2, r.height + n
				* 2);
	}

	public static Point[] getDragPoints(Rectangle rect) {
		int x1 = rect.x, y1 = rect.y, x2 = rect.x + rect.width, y2 = rect.y
				+ rect.height;
		int xm = (x1 + x2) / 2;
		int ym = (y1 + y2) / 2;

		return new Point[] { new Point(xm, y1), new Point(x2, y1),
				new Point(x2, ym), new Point(x2, y2), new Point(xm, y2),
				new Point(x1, y2), new Point(x1, ym), new Point(x1, y1) };
	}

	private int getDir(Rectangle r, Point p) {
		Point[] ps = getDragPoints(r);
		for (int i = 0; i < ps.length; i++) {
			if (ps[i].distance(p) <= 2)
				return i;
		}
		if (r.contains(p))
			return IN;
		return OUT;
	}

	@Override
	public void mouseDragged(MouseEvent e) {
		if (dragging) {
			onDrag(e.getPoint());
		}
	}

	@Override
	public void mouseMoved(MouseEvent e) {
		Point p = e.getPoint();
		int d = getDir(rect, p);
		int c;
		switch (d) {
		case N:
			c = Cursor.N_RESIZE_CURSOR;
			break;
		case NE:
			c = Cursor.NE_RESIZE_CURSOR;
			break;
		case E:
			c = Cursor.E_RESIZE_CURSOR;
			break;
		case SE:
			c = Cursor.SE_RESIZE_CURSOR;
			break;
		case S:
			c = Cursor.S_RESIZE_CURSOR;
			break;
		case SW:
			c = Cursor.SW_RESIZE_CURSOR;
			break;
		case W:
			c = Cursor.W_RESIZE_CURSOR;
			break;
		case NW:
			c = Cursor.NW_RESIZE_CURSOR;
			break;
		case IN:
			c = Cursor.MOVE_CURSOR;
			break;
		default:
			c = Cursor.DEFAULT_CURSOR;
			break;
		}
		editor.setCursor(new Cursor(c));
	}
}
