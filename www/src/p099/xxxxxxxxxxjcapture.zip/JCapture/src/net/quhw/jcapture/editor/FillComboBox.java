package net.quhw.jcapture.editor;

import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Graphics;

import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JList;
import javax.swing.ListCellRenderer;

public class FillComboBox extends JComboBox {
	private static final long serialVersionUID = 8395902984305842884L;

	public FillComboBox() {
		setEditable(false);

		addItem(false);
		addItem(true);

		setSelectedIndex(0);

		setRenderer(new FillRenderer());
	}

	public boolean getFillMode() {
		return (Boolean) getSelectedItem();
	}

	private class FillRenderer implements ListCellRenderer {
		@Override
		public Component getListCellRendererComponent(JList list, Object value,
				int index, boolean isSelected, boolean cellHasFocus) {
			return new FillComp((Boolean) value, isSelected);
		}
	}

	private static class FillComp extends JComponent {
		private static final long serialVersionUID = -8534083919607117529L;

		private boolean fill;
		private boolean selected = false;

		public FillComp(boolean fill, boolean selected) {
			this.fill = fill;
			this.selected = selected;
		}

		@Override
		public void paint(Graphics g) {
			if (selected) {
				g.setColor(Color.blue);
			} else {
				g.setColor(Color.white);
			}
			g.fillRect(0, 0, getWidth(), getHeight());
			if (fill)
				g.setColor(Color.gray);
			else
				g.setColor(Color.white);
			g.fillRect(2, 2, getWidth() - 4, getHeight() - 4);
			g.setColor(Color.black);
			g.drawRect(2, 2, getWidth() - 5, getHeight() - 5);
		}

		@Override
		public Dimension getPreferredSize() {
			return new Dimension(32, 16);
		}

	}
}
